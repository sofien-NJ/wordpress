﻿# Creativeily Blog

**Contributors:** themeeverest  
**Requires at least:** WordPress 4.0  
**Tested up to:** WordPress 5.0  
**Stable tag:** 1.2
**Version:** 1.2
**License:** GPLv2 or later  
**License URI:** http://www.gnu.org/licenses/gpl-2.0.html  
**Tags:** two-columns, right-sidebar, flexible-header, custom-background, custom-colors, custom-header, custom-menu, custom-logo, featured-images, footer-widgets, theme-options, threaded-comments, translation-ready, blog, entertainment, news

Creativeily Blog is your seo friendly & responsive theme made for blogging, newspapers or journalist writing. The code is clean so your website will be quick and load fast with great page speed. The theme is simple to setup but has a lot of features for both affiliate marketing, i.e. lots of advertisement space for affiliate programs such as Google AdSense - of course this kind of website requires a SEO optimized, creative & modern theme which Creativeily Blog is. Creativeily Blog is a true multi purpose theme, Beaver Pagebuilder is implemented so you can create your corporate business landing page, an elegant agency one page or a simply photography portfolio. Authors & bloggers can easily create a simple and minimalistic blog and customize it to a niche with the header, so you can write about anything from food, travel, fashion, lifestyle, reviews, products or other entertainment niches. To sum it up the theme is SEO optimised, responsive so it works on tablets, desktop, mobile phones, on every device, such as an Apple or Android. The theme allows you to create a news paper or 1 page / single page, coach, school or education conference website with very low amount of effort required since the design looks beautiful out of box.

## Description

Creativeily Blog is your seo friendly & responsive theme made for blogging, newspapers or journalist writing. The code is clean so your website will be quick and load fast with great page speed. The theme is simple to setup but has a lot of features for both affiliate marketing, i.e. lots of advertisement space for affiliate programs such as Google AdSense - of course this kind of website requires a SEO optimized, creative & modern theme which Creativeily Blog is. Creativeily Blog is a true multi purpose theme, Beaver Pagebuilder is implemented so you can create your corporate business landing page, an elegant agency one page or a simply photography portfolio. Authors & bloggers can easily create a simple and minimalistic blog and customize it to a niche with the header, so you can write about anything from food, travel, fashion, lifestyle, reviews, products or other entertainment niches. To sum it up the theme is SEO optimised, responsive so it works on tablets, desktop, mobile phones, on every device, such as an Apple or Android. The theme allows you to create a news paper or 1 page / single page, coach, school or education conference website with very low amount of effort required since the design looks beautiful out of box.


## Copyright
Creativeily Blog WordPress Theme, Copyright 2018 themeeverest
Creativeily Blog is distributed under the terms of the GNU GPL

Creativeily Blog bundles the following third-party resources:


This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

______
IMG FROM SCREENSHOT
CC0 License

Unless otherwise specified, all the theme files, scripts and images are licensed under GPLv2 or later and created by our team.
- https://pxhere.com/en/photo/10354  CC0 Public Domain Free for personal and commercial use No attribution required Learn more

Bootstrap - http://getbootstrap.com/
Licensed Under MIT( https://opensource.org/licenses/MIT)

* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2018 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

html5shiv - http://code.google.com/p/html5shiv/
License Under MIT (http://opensource.org/licenses/MIT)

Font Awesome - http://fortawesome.github.io/Font-Awesome/
Font License
Applies to all desktop and webfont files in the following directory: font-awesome/font/.
License: SIL OFL 1.1
URL: http://scripts.sil.org/OFL
Code License
Applies to all CSS and LESS files in the following directories: font-awesome/css/ and font-awesome/less/.
License: MIT License
URL: http://opensource.org/licenses/mit-license.html


 - Open Sans - 
 License: Apache License, version 2.0
 License URI: http://www.apache.org/licenses/LICENSE-2.0.html

 - Fira Sans - http://fonts.googleapis.com/css?family=Fira+Sans
 License: SIL Open Font License, 1.1
 License URI: http://scripts.sil.org/OFL

 * Font-Awesome
 License: GPL Friendly
 License URI: https://fortawesome.github.io/Font-Awesome/license/

 * Scripts in folder js 
 * customizer.js
 * navigation.js
 * skip-link-focus-fix.js
 * jQuery FlexSlider v2.2.2

 License: GNU General Public License v2 or later
 License URI: http://www.gnu.org/licenses/gpl-2.0.html
 Copyright: Automattic http://underscores.me/

* html5shiv - http://code.google.com/p/html5shiv/ License Under MIT (http://opensource.org/licenses/MIT)
* A light gradient has been applied to the wood image and the city image


* Bootstrap - http://getbootstrap.com/
	Licensed Under MIT( https://opensource.org/licenses/MIT)

* Flex slider 
	* We Use Flex slider by Jeffrey Pearce
	* GNU General Public License v2.0
	* https://github.com/woocommerce/FlexSlider/blob/master/LICENSE.md
* Based on Underscores (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
 	* License: GNU General Public License v2 or later
	* License URI: http://www.gnu.org/licenses/gpl-2.0.html
	* Copyright: Automattic http://underscores.me/
* Based on Flatmagazinews https://wordpress.org/themes/flatmagazinews/ 
	* (C) 2012-2018 ThemeEverest, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Based on Bloggist https://wordpress.org/themes/bloggist/ 
	* (C) 2012-2018 ThemeEverest, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Based on Draco https://wordpress.org/themes/draco/
	* (C) 2018-2019 extendyourweb, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html) Forked Draco by extendyourweb published on WordPress.org & published under GPLv2: https://wordpress.org/themes/draco/ -- https://www.webpsilon.com/en/wpthemes //  Webpsilon Soluciones Integrales en Internet S.L. - Thank you so much for creating this awesome ttheme we have used as foundation for our own theme, especially the header is an amazing idea, we have respectfully given the theme a full redesign but kept most of the header design and functionality.

* normalize.css http://necolas.github.io/normalize.css/, (C) 
	* 2012-2018 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

* html5shiv - http://code.google.com/p/html5shiv/
	*License Under MIT (http://opensource.org/licenses/MIT)

* Font Awesome - http://fortawesome.github.io/Font-Awesome/
	* Font License
	* Applies to all desktop and webfont files in the following directory: /fonts/.
	* License: SIL OFL 1.1
	* URL: http://scripts.sil.org/OFL
	* Code License
	* Applies to all CSS and LESS files in the following directories: /css/ and /less/.
	* License: MIT License
	* URL: http://opensource.org/licenses/mit-license.html
	* Documentation License
	* Applies to all Font Awesome project files that are not a part of the Font or Code licenses.
	* License: CC BY 3.0
	* URL: http://creativecommons.org/licenses/by/3.0/

* Open Sans 
	* License: Apache License, version 2.0
	* License URI: http://www.apache.org/licenses/LICENSE-2.0.html

 * Fira Sans - http://fonts.googleapis.com/css?family=Fira+Sans
	* License: SIL Open Font License, 1.1
	* License URI: http://scripts.sil.org/OFL

* Font-Awesome
	* License: GPL Friendly
	* License URI: https://fortawesome.github.io/Font-Awesome/license/

 * Scripts in folder js 
	* All scripts that are not third party is coded by me and they are under license GPLv2 or later: http://www.gnu.org/licenses/gpl-2.0.html
		 * customizer.js
		 * navigation.js
		 * skip-link-focus-fix.js
		 * jQuery FlexSlider v2.2.2

* html5shiv - http://code.google.com/p/html5shiv/ License Under MIT (http://opensource.org/licenses/MIT)

* Screenshot is created by us, so is the description, both are GPL v2 or later

* Icons are GPLv2 as well, made by me in Adobe Illustrator

* html5shiv - http://code.google.com/p/html5shiv/ License Under MIT (http://opensource.org/licenses/MIT)

* Screenshot icons and images in /icons are GPLv2 as well are GPLv2 as well made in Adobe Illustrator 6

* Addons.js is copyrighted GPLv2 as well

* Font: Creativeily Blog Fonts
	License: SIL OFL 1.1
	License: CC0 License

* Woocommerce copyrighted by Automaticc is integrated: https://wordpress.org/plugins/woocommerce/

* The logo is made by us in Illustrator

* Copyright and License for Upsell button by Justin Tadlock - 2016 © Justin Tadlock.
	* Link: https://github.com/justintadlock/trt-customizer-pro
	* License: GPL Friendly
	* License URI: https://github.com/justintadlock/trt-customizer-pro/blob/master/license.md

* We use TGM Plugin Activation (TGMPA) http://tgmpluginactivation.com/ 
*  TGM Plugin Activation
	*The TGM Plugin Activation library is licensed under the GPL-2.0 or later license. https://opensource.org/licenses/GPL-2.0
	* [![GitHub license](https://img.shields.io/badge/license-GPLv2-blue.svg)](https://raw.githubusercontent.com/TGMPA/TGM-Plugin-Activation/develop/LICENSE.md)
	* [![Build Status](https://travis-ci.org/TGMPA/TGM-Plugin-Activation.svg?branch=develop)](https://travis-ci.org/TGMPA/TGM-Plugin-Activation)
	* [![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/TGMPA/TGM-Plugin-Activation/badges/quality-score.png?b=develop)](https://scrutinizer-ci.com/g/TGMPA/TGM-Plugin-Activation/?branch=develop)
* Beaver Builder Lite Version is implemented into the theme: https://wordpress.org/plugins/beaver-builder-lite-version/ it is licensed under GPL v2 or later
